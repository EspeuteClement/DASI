/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.insalyon.dasi.td.jpa;

import java.util.Collection;
import java.util.Vector;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author vcapelle
 */
public class Main {
    
    
    public static void main(String[] args)
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("fr.insalyon.dasi_TD-JPA_jar_1.0-SNAPSHOTPU");
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        
        /* // Ajout d'une Personne
        Personne benoit = new Personne("Capelle","Victor",95,03,27,20);
        
        System.out.println(benoit.toString());
        
        benoit.setId(2L);
        
        tx.begin();
        em.persist(benoit);
        tx.commit();    
        em.close();
        */

        /*  // Trouver et afficher une personne
        Personne p1 = em.find(Personne.class,2L);
        
        System.out.println(p1.toString());
                */
        
       Query query = em.createQuery("SELECT e FROM Personne e");
       Vector<Personne> allPersonne = (Vector<Personne>) query.getResultList();

       for (int i = 0; i < allPersonne.size(); i++)
       {
           System.out.println(allPersonne.elementAt(i));
       }
    }
    
    
    
}
